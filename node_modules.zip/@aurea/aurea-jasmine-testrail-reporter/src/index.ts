import assert from "assert";
import _ from 'underscore';
import CustomReporter = jasmine.CustomReporter;
import CustomReporterResult = jasmine.CustomReporterResult;
import SuiteInfo = jasmine.SuiteInfo;
const testRailApi = require('testrail-api');
const currentWeekNumber = require('current-week-number');
const BUILD_NUMBER = process.env.BUILD_NUMBER;
let generatedPlanId=0;
interface IExtendedCustomReporterResult extends CustomReporterResult {
    specs?: CustomReporterResult[];
}

interface ArrayOfExtendedCustomReporterResults {
    [index: string]: IExtendedCustomReporterResult;
}

const MODULE_NAME = 'aurea-jasmine-testrail-reporter';

enum EStatuses {
    Passed = 1,
    Blocked = 2,
    Untested = 3,
    Retest = 4,
    Failed = 5,
    Disabled = 8,
    Pending = 8
}

const jasmineToTestRailStatusesMatching: { [index: string]: EStatuses } = {
    'passed': EStatuses.Passed,
    'disabled': EStatuses.Disabled,
    'pending': EStatuses.Pending,
    'failed': EStatuses.Failed,
};

export class Reporter implements CustomReporter {
    private milestoneId: number = 0;
    private milestones: any = {};
    private testRailApiObject: any;
    private suitesFromServer: any[] = [];
    private specResults: CustomReporterResult[] = [];
    private jasmineResults: ArrayOfExtendedCustomReporterResults = {};
    private plans: any = {};
    private planName: any = '';
    private _asyncFlow: Promise<any> | null = null;
    private milestoneName='';
    constructor(hostname: string,
                username: string,
                password: string,
                private projectId: number,
                private versionName: string,
                private osName = 'OS_NAME',
                private browserName = 'BROWSER_NAME',
                private milestoneNamePrefix = 'Automation milestone week',
                private planNamePrefix = 'Automation Test Plan') {
        if (!BUILD_NUMBER) {
            console.log('Environment variable BUILD_NUMBER is not present so Test rail will not post results');
            return;
        }
        assert(username, `${MODULE_NAME}: email parameter should not be empty!`);
        assert(password, `${MODULE_NAME}: password parameter should not be empty!`);
        assert(typeof projectId === 'number', `${MODULE_NAME}: projectId parameter is wrong!`);

        if (!username) throw(new Error(`${MODULE_NAME}: email parameter should not be empty!`));
        if (!password) throw(new Error(`${MODULE_NAME}: password parameter should not be empty!`));

        this.testRailApiObject = new testRailApi({
            host: hostname,
            user: username,
            password: password
        });


    }

    public async asyncInit() {
        if (Number(this.projectId)) {
            this.projectId = Number(this.projectId)
        }

        await this.testRailApiObject
            .getMilestones(this.projectId)
            .then((result: any) => {
                this.milestones = result.body;
            })
            .catch((error: any) => {
                console.log("getMilestones error");
                console.log(error.message);
            });

        this.milestoneName = `${this.milestoneNamePrefix} ${currentWeekNumber(new Date().getUTCDate())}`;
        this.planName = `${this.planNamePrefix} CI Build#${BUILD_NUMBER} ${this.osName}-${this.browserName}`;

        const fetchedMilestones = this.milestones.filter((data: any) => {
            return data.name === this.milestoneName;
        });

        const timestamp = new Date().toUTCString();
        if (!fetchedMilestones[0]) {
            const newMilestone = {
                name: this.milestoneName,
                description: this.milestoneName + " created by automation framework on " + timestamp,
                started_on: new Date().getTime()
            };
            let milestone = {id: 0};
            await this.testRailApiObject
                .addMilestone(this.projectId, newMilestone)
                .then((result: any) => {
                    milestone = result.body;
                })
                .catch((error: any) => {
                    console.log("addMilestone error");
                    console.log(error.message);
                });
            this.milestoneId = milestone.id;
        }
        else {
            this.milestoneId = fetchedMilestones[0].id;
        }
        await this.testRailApiObject
            .getSuites(this.projectId)
            .then((result: any) => {
                this.suitesFromServer = result.body;
            })
            .catch((error: any) => {
                console.log("getSuites error");
                console.log(error.message);
            });

        await this.testRailApiObject
            .getPlans(this.projectId, {milestone_id: this.milestoneId})
            .then((result: any) => {
                this.plans = result.body;
            }).catch((error: any) => {
                console.log("getPlans error");
                console.log(error.message);
            });

    }

    public getSuiteNameById(suiteId: number) {
        const suite = this.suitesFromServer.filter(function (suite: any) {
            return suite.id === suiteId;
        });
        assert(suite[0], `${MODULE_NAME}: Suite id not found in collection!`);
        return suite[0].name;
    }

    public getSuiteId(suiteName: string) {
        const suite = this.suitesFromServer.filter(function (suite: any) {
            return suite.name === suiteName;
        });
        assert(suite[0], `${MODULE_NAME}: Suite name not found in collection!`);
        return suite[0].id;
    };

    public async closePlan(planId = generatedPlanId) {
        await this.testRailApiObject
            .closePlan(planId)
            .then((result: any) => {
               console.log(`Plan id ${planId} Closed Successfully`);
            })
            .catch((error: any) => {
                console.log("closePlan error");
                console.log(error.message);
            });
    };

    jasmineStarted(suiteInfo: SuiteInfo) {
        /* Wait for async tasks triggered by `specDone`. */
        beforeEach(async () => {
            await this._asyncFlow;
            this._asyncFlow = null;
        });
    }

    specDone(result: CustomReporterResult) {

        this.specResults.push(result);
        this._asyncFlow = this._asyncSpecDone(result);

    }

    async _asyncSpecDone(result: any) {

        // @todo: Do your async stuff here depending on `result.status`, take screenshots etc...
        // await takeScreenShot();
    }

    suiteDone(result: CustomReporterResult) {
        this.jasmineResults[result.id] = result;
        this.jasmineResults[result.id].specs = this.specResults;
        this.specResults = [];
    }

    async publishResults() {
        if (!BUILD_NUMBER) {
            throw new Error(`${MODULE_NAME}: Enviroment variable BUILD_NUMBER is not present results will not be posted`);
        }
        await this.asyncInit();

        const allSpecsFromAllSuites: CustomReporterResult[] = [].concat.apply([],
            Object.keys(this.jasmineResults)
                .map(key => this.jasmineResults[key])
                .map((suite: any) => suite.specs));

        const addResultsForCases = allSpecsFromAllSuites.map(spec => {

                spec.failedExpectations = spec.failedExpectations || [];
                spec.status = spec.status || '';

                let caseId = 0;
                const caseIdRegexMatch = /\[[cC]?(\d+)\]/.exec(spec.description);
                if (caseIdRegexMatch) {
                    caseId = Number(caseIdRegexMatch[1]);
                } else {
                    throw new Error(`${MODULE_NAME}: The TestRail case number is not specified in the jasmine case title and more than one titles match.`);
                }

            let defectId = '';
            if (spec.status === 'disabled' || spec.status === 'failed' || spec.status === 'pending') {
                const defectIdRegexMatch = /\[BUG:([A-Za-z][A-Z]+-\d+)\]/.exec(spec.description);
                if (defectIdRegexMatch) {
                    defectId = defectIdRegexMatch[1];
                    let failedExpectation: any = {
                        message: spec.pendingReason
                    };
                    spec.failedExpectations.push(failedExpectation);
                }
            }
            return {
                case_id: caseId,
                suite_id: this.getSuiteId(spec.fullName.replace(spec.description, '').trim()),
                status_id: jasmineToTestRailStatusesMatching[spec.status],
                version: this.versionName,
                defects: defectId,
                comment:
                    spec.failedExpectations
                        .map(
                            el => `matcherName = ${el.matcherName}
                            \n message = ${el.message}
                            \n expected = ${el.expected}
                            \n actual=${el.actual}`
                        ).join('\n\n')
            };
        });

        const getTestBySuiteId = function (suiteId: number) {
            return addResultsForCases.filter(function (item) {
                return item.suite_id === suiteId;
            });
        };

        // Get all suite IDs
        const suiteIds = _.uniq(_.pluck(addResultsForCases, "suite_id"));
        const timestamp = new Date().toUTCString();

        await Promise.all(suiteIds.map(async (suiteId:number) => {

            // Add plan if plan is unavailable
            const requiredPlans = this.plans.filter((entry: any) => {
                return entry.name === this.planName;
            });

            let planId:any;
            if(generatedPlanId>0){
               planId = generatedPlanId;
            }
            else if (!requiredPlans[0]) {
                await this.testRailApiObject
                    .addPlan(this.projectId, {name: this.planName, milestone_id: this.milestoneId})
                    .then((result: any) => {
                        planId = result.body.id;
                        generatedPlanId = planId;
                    })
                    .catch((error: any) => {
                        console.log("addPlan error");
                        console.log(error.message);
                    });
            }
            else {
                planId = requiredPlans[0].id;
                generatedPlanId = planId;
            }

            // Add plan entry based on suite IDs
            const newPlanEntry = {
                suite_id: suiteId,
                name: `Suite '${this.getSuiteNameById(suiteId)}' execution`,
                description: `Run for suite  ${this.getSuiteNameById(suiteId)} created by automation framework on ${timestamp}`,
                milestone_id: this.milestoneId,
                include_all: false,
                case_ids: getTestBySuiteId(suiteId).map(function (item) {
                    return item.case_id;
                })
            };

            let planEntry: any={};
            await this.testRailApiObject
                .addPlanEntry(planId, newPlanEntry)
                .then((result: any) => {
                        planEntry = result.body;
                })
                .catch((error: any) => {
                    console.log("addPlanEntry error");
                    console.log(error.response);
                    console.log(error.message);
                });


            // Add Results for tests
            await this.testRailApiObject
                .addResultsForCases(planEntry.runs[0].id, addResultsForCases.filter(addResultsForCase => addResultsForCase.suite_id === suiteId))
                .then((result: any) => {
                    planEntry = result.body;
                })
                .catch((error: any) => {
                    console.log("addResultsForCases error");
                    console.log(error.response);
                    console.log(error.message);
                });

            await this.deleteAndCompleteMilestones(this.milestoneName,this.milestoneNamePrefix);
        }));
    }

    async deleteAndCompleteMilestones(milestoneName: string, milestonePrefix: string) {
        return await Promise.all(this.milestones.map(async (milestone: any) => {
            if (milestone.name != milestoneName
                && !milestone.is_completed
                && (milestone.name.indexOf(milestonePrefix) > -1 ||
                    (milestone.description && milestone.description.toLowerCase().indexOf(milestonePrefix) > -1))) {
                await this.testRailApiObject
                    .updateMilestone(milestone.id,
                        {is_completed: true})
                    .then((result: any) => {
                        console.log(`Milestone ${milestone.id} is deleted`);

                    }).catch((error: any) => {
                        console.log("updateMilestone error");
                        console.log(error.message);
                    });
            }
            /*if (milestone.is_completed) {
                const timeDiff = Math.abs(new Date(milestone.started_on).getTime() - new Date().getUTCDate());
                const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                if (diffDays > 90) {
                    await this.testRailApiObject
                        .deleteMilestone(milestone.id)
                        .then((result: any) => {
                            console.log(`Milestone ${milestone.id} is deleted`);
                        }).catch((error: any) => {
                            console.log("deleteMilestone error");
                            console.log(error.message);
                        });
                }
            }*/
        }));
    }
}
