### Important note

** This reporter is created specifically for capturing CI results, If you want to get it working on local machine
then make sure that you set environment variable BUILD_NUMBER **

### Installation

Run following command to install package via npm
```
npm install @aurea/aurea-jasmine-testrail-reporter
```

Since it utilizes local registry we must specify the registry entry in .npmrc file in the root, So @aurea prefix will be resolved using cenral registry. Registry entry should be like following. You can also use the .npmrc file which is available in the root of this repository
```
@aurea:registry=https://nexus.devfactory.com/repository/aurea-automation-utils/
```

### How it works?

* It creates a milestone per week with title like following
```
Example - Automation milestone week <CurrentWeekNumberPerYear>
```

* It creates a plan for each CI Run
```
Example - Automation Test Plan CI Build#<BuildId> <OS_NAME>-<BROWSER_NAME>
```

* It creates a plan entry with Run
```
Example - Suite '<Suite name>' execution
```
**Suite name must match test rail suite**

### It adds 3 statuses

* Passed  - All the passing tests
* Failed  - All the failing tests
* Skipped - For all the tests which are disabled (marked with xit)



### Test writing instructions

Please make sure that `suite name` in test rail and in *-specs.ts is same and test case has an id append to name with bracket, Here `suite name` is defined in describe and `test id` is defined as [1].
Example

```javascript
describe("This should be the suite name", function() {
  it("Mind the id at the end of this with bracket - [1]", function() {
    expect(true).toBe(true);
  });
});
```

### Defect linking in testrail for the ignored tests

If we want to associate bug id with test case in a run then we must append the bug id in test name like [BUG:XXX-00000],
Please note that it must be ignored then only it will be associated with test case, This test case will be marked as skipped
in test rail

Example

```javascript
describe("This should be the suite name", function() {
  xit("Mind the id at the end of this with bracket - [1] [BUG:SNSGCID-19909]", function() {
    expect(true).toBe(true);
  });
});
```

### You can configure this reporter in following way to any protractor project

```javascript
    const TestRailReporter = require('@aurea/aurea-jasmine-testrail-reporter');
    let trReporter = null;
    onPrepare() {
        trReporter = new TestRailReporter.Reporter(
            <hostname>, // https://testrail.devfactory.com
            <Username>, // AdUserName or email Id
            <Password>, // Password with Ad Username and Token with email Id
            <ProjectId>, // Testrail Project Id
            <VersionName>, // process.env.version || browser.params.version which can be passed using --params.version
            <OsName>: // e.g. Windows - Linux
            <BrowserName>?: // e.g. Chrome/Mozilla,
            <MilestoneNamePrefix>, // Default - 'Automation milestone week'
            <PlanNamePrefix>, // Default - 'Automation Test Plan'
        );
        jasmine.getEnv().addReporter(trReporter);
    },
    onComplete() {
        return trReporter.publishResults()
            .then(results => {
                console.log('Test results are posted');
            })
            .catch(err => {
                console.log(err.message);
            });
    }
```

### To get windows name and browser name, You can utilize following code

```javascript
browser.getCapabilities().then(function (cap) {
  platform = cap.get('platform');
  browserName = cap.get('browserName');
});
```

### Documentation

https://docs.google.com/document/d/1QAv5gtNbiaAO1NWCzSnzzD0vTpKD20-hMEELQoJRU4k/edit?usp=sharing